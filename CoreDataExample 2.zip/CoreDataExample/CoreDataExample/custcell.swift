

import UIKit

class custcell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
     
    }
    @IBOutlet weak var lblname: UILabel!

    @IBOutlet weak var lbladd: UILabel!
    
    @IBOutlet weak var lblid: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
       
        super.setSelected(selected, animated: animated)

           }

}
